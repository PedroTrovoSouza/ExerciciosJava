package org.example.repositorio;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import org.example.entidade.Dinossauros;

import java.util.List;

public class RepositorioDinossauros {

    private static final EntityManagerFactory emf = Persistence.createEntityManagerFactory("hiberMySQL");

    public void salvar(Dinossauros dinos) {
        EntityManager em = emf.createEntityManager();
        try {
            em.getTransaction().begin();
            em.merge(dinos);
            em.getTransaction().commit();
        } catch (Exception e) {
            if (em.getTransaction().isActive()) em.getTransaction().rollback();
            e.printStackTrace();
        } finally {
            em.close();
        }
    }

    public void remover(Dinossauros dinos) {
        EntityManager em = emf.createEntityManager();
        try {
            em.getTransaction().begin();
            Dinossauros d = em.merge(dinos); // precisa estar "gerenciado" para remover
            em.remove(d);
            em.getTransaction().commit();
        } catch (Exception e) {
            if (em.getTransaction().isActive()) em.getTransaction().rollback();
            e.printStackTrace();
        } finally {
            em.close();
        }
    }

    public Dinossauros obterPorCod(int codigo) {
        EntityManager em = emf.createEntityManager();
        Dinossauros dino = em.find(Dinossauros.class, codigo);
        em.close();
        return dino;
    }

    public List<Dinossauros> listarTodos() {
        EntityManager em = emf.createEntityManager();
        List<Dinossauros> dinos = em.createQuery("from Dinossauros", Dinossauros.class).getResultList();
        em.close();
        return dinos;
    }
}
