package org.example.testes;

import org.example.entidade.Dinossauros;
import org.example.repositorio.RepositorioDinossauros;

import java.util.List;

public class TesteHiber5 {
    public static void main(String[] args) {
        RepositorioDinossauros repDino = new RepositorioDinossauros();
        Dinossauros dino = new Dinossauros();

        Dinossauros dino2 = new Dinossauros();
        dino2.setEspecie("Taurandios");
        dino2.setGenero("SufilosBasculinos");
        repDino.salvar(dino2);

        Dinossauros dino3 = new Dinossauros();
        dino3.setEspecie("Tiranusauros");
        dino3.setGenero("SufriciosSacrifis");
        repDino.salvar(dino3);

        dino = repDino.obterPorCod(1);
        System.out.println("Registro da Tabela Dinossauros Antes da Alteração");
        System.out.println("#############################################");
        System.out.println("Gênero do Dinossauro.:" + dino.getGenero());
        System.out.println("Espéice do Dinossauro:" + dino.getEspecie());
        System.out.println("#############################################");
        dino.setEspecie("Basculanos Alterado");
        dino.setGenero("Varandanilius Alterado");
        repDino.salvar(dino);
        System.out.println("Registro da Tabela Dinossauros Após Alteração");
        System.out.println("#############################################");
        System.out.println("Gênero do Dinossauro.:" + dino.getGenero());
        System.out.println("Espéice do Dinossauro:" + dino.getEspecie());
        System.out.println("#############################################");

        List<Dinossauros> dinossauros = repDino.listarTodos();

        for (int i = 0; i < dinossauros.size(); i++) {
            System.out.println("Genero do Dinossauro: " + dinossauros.get(i).getGenero());
            System.out.println("Espécie do Dinossauro: " + dinossauros.get(i).getEspecie());
            System.out.println("#################################################");
        }
    }
}
