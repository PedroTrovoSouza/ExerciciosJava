package org.example;
import jakarta.persistence.*;

@Entity
@DiscriminatorValue("LIVRO_ELETRONICO")
public class Eletronico  extends Livro{

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    int id_eletronico;

    private int tamanho;

    public int getTamanho() {
        return tamanho;
    }

    public void setTamanho(int tamanho) {
        this.tamanho = tamanho;
    }

    @Override
    public String toString() {
        return "Eletronico{" +
                "id_eletronico=" + id_eletronico +
                ", tamanho=" + tamanho +
                '}';
    }
}
