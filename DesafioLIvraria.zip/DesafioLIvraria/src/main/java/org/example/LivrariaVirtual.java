package org.example;

import java.util.List;
import java.util.Scanner;

public class LivrariaVirtual {
    private final int MAX_IMPRESSOS = 10;
    private final int MAX_ELETRONICOS = 20;
    private final int MAX_VENDAS = 50;
    private int numImpressos;
    private int numEletronicos;
    private int numVendas;
    private List<Impresso> impressos;
    private List<Eletronico> eletronicos;
    private List<Venda> venda;

    public LivrariaVirtual() {
    }

    public LivrariaVirtual(int numImpressos, int numEletronicos, int numVendas) {
        this.numImpressos = numImpressos;
        this.numEletronicos = numEletronicos;
        this.numVendas = numVendas;
    }

    public void cadastrarLivro() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Selecione as Opções de cadastro");
        System.out.println("1. Impresso");
        System.out.println("2. Digital");
        System.out.println("3. Ambos");

        int opcaoCadastro = scanner.nextInt();

        if ((opcaoCadastro == 1 || opcaoCadastro == 3) && eletronicos.size() >= MAX_ELETRONICOS)  {
            System.out.println("Não à espaço suficiente na lista");
            return;
        }

        if ((opcaoCadastro == 2 || opcaoCadastro == 3) && impressos.size() >= MAX_IMPRESSOS) {
            System.out.println("Não à espaço suficiente na lista");
            return;
        }

        System.out.println("Digite o título do livro:");
        String titulo = scanner.nextLine();
        System.out.println("Digite o autor:");
        String autor = scanner.nextLine();
        System.out.println("Digite a editora:");
        String editora = scanner.nextLine();
        System.out.println("Digite o preço:");
        Double preco = scanner.nextDouble();


    }

    public void realizarVenda() {

    }

    public void listarLivrosImpressos() {

    }

    public void listarLivrosEletronicos() {

    }

    public void listarLivros() {

    }

    public void listarVendas() {

    }

    public static void main(String[] args) {

    }
}