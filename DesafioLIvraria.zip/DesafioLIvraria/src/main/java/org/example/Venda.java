package org.example;

public class Venda {
}
