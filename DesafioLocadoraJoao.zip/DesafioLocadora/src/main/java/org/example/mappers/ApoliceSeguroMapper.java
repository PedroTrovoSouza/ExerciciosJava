package org.example.mappers;

import org.example.DTO.ApoliceSeguroRequestDTO;
import org.example.entity.ApoliceSeguro;

public class ApoliceSeguroMapper {

//    incompleto
    public ApoliceSeguro toEntity (ApoliceSeguroRequestDTO dto) {
        ApoliceSeguro apolice = new ApoliceSeguro();
        apolice.setValorFranquia(dto.getValorFranquia());
        apolice.setProtecaoTerceiro(dto.getProtecaoTerceiro());
        apolice.setProtecaoCausasNaturais(dto.getProtecaoCausasNaturais());
        apolice.setProtecaoRoubo(dto.getProtecaoRoubo());
    }
}
