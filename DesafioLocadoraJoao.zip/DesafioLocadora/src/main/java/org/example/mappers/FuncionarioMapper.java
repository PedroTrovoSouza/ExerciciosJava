package org.example.mappers;

public class FuncionarioMapper {
}
