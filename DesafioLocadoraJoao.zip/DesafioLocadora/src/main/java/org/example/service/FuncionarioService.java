package org.example.service;

public class FuncionarioService {
}
