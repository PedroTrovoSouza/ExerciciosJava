package org.example.service;

public class ApoliceSeguroService {
}
