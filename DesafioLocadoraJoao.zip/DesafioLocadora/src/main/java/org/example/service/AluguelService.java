package org.example.service;

public class AluguelService {
}
