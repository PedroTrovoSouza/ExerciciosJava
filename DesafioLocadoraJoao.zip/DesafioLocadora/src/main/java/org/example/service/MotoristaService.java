package org.example.service;

public class MotoristaService {
}
