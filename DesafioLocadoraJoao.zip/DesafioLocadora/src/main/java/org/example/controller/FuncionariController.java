package org.example.controller;

public class FuncionariController {
}
