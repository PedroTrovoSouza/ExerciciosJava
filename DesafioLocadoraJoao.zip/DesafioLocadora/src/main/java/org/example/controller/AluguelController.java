package org.example.controller;

public class AluguelController {
}
