package org.example.enums;

public enum Sexo {
    MASCULINO,
    FEMININO
}