package empresa;

public class Veterinario {

    public void examinar(
            Preguica preguica,
            Cachorro cachorro,
            Cavalo cavalo
    ) {
        preguica.emitirSom();
        cachorro.emitirSom();
        cavalo.emitirSom();
    }
}
