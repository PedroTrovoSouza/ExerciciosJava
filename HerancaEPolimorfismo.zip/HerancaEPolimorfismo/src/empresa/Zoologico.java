package empresa;

public class Zoologico {
    public static void main(String[] args) {
        Animal[] animais = new Animal[10];

        animais[0] = new Cachorro();
        animais[1] = new Cachorro();
        animais[2] = new Cachorro();
        animais[3] = new Cavalo();
        animais[4] = new Cavalo();
        animais[5] = new Cavalo();
        animais[6] = new Cavalo();
        animais[7] = new Preguica();
        animais[8] = new Preguica();
        animais[9] = new Preguica();

        for (Animal a : animais) {
            if(a instanceof Cachorro) {
                a.emitirSom();
                a.moverse();
            }
            if (a instanceof Cavalo) {
                a.emitirSom();
                a.moverse();
            }
            a.emitirSom();
        }
    }
}
