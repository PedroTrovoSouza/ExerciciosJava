package empresa;

public class Cachorro extends Animal{
    @Override
    public void emitirSom() {
        System.out.println("Au Au!");
    }

    @Override
    public void moverse() {
        System.out.println("Correndo");
    }
}
