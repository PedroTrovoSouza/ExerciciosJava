package empresa.atividadeEmpresa;

public class ComissaoGerente extends Comissao {
    @Override
    public double getValorComissao() {
        return 1500.0;
    }
}
