package empresa.atividadeEmpresa;

public abstract class Comissao {
    public abstract double getValorComissao();
}

