package empresa.atividadeEmpresa;

public class FuncionarioGraduado extends FuncionarioMedio {
    protected String universidade;

    public FuncionarioGraduado(String nome, String registroEmpresa, String escolaBasico, String escolaMedio, String universidade) {
        super(nome, registroEmpresa, escolaBasico, escolaMedio);
        this.universidade = universidade;
    }

    @Override
    public Double calcularRendaTotal() {
        double rendaAnterior = super.calcularRendaTotal(); // já vem com básico + médio
        double renda = rendaAnterior * 2.0; // mais 100%
        if (comissao != null) {
            renda += comissao.getValorComissao();
        }
        return renda;
    }
}

