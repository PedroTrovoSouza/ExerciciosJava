package empresa.atividadeEmpresa;

public class FuncionarioMedio extends FuncionarioBasico {
    protected String escolaMedio;

    public FuncionarioMedio(String nome, String registroEmpresa, String escolaBasico, String escolaMedio) {
        super(nome, registroEmpresa, escolaBasico);
        this.escolaMedio = escolaMedio;
    }

    @Override
    public Double calcularRendaTotal() {
        double rendaAnterior = super.calcularRendaTotal(); // já vem com 10% do básico
        double renda = rendaAnterior * 1.50; // mais 50%
        if (comissao != null) {
            renda += comissao.getValorComissao();
        }
        return renda;
    }
}

