package empresa.atividadeEmpresa;

public class Funcionario {
    private String nome;
    private String escolaridade;
    private String registroEmpresa;
    protected Double rendaBasica = 1000.0;

    protected Comissao comissao;

    public Funcionario() {}

    public Funcionario(String nome, String registroEmpresa) {
        this.nome = nome;
        this.registroEmpresa = registroEmpresa;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEscolaridade() {
        return escolaridade;
    }

    public void setEscolaridade(String escolaridade) {
        this.escolaridade = escolaridade;
    }

    public String getRegistroEmpresa() {
        return registroEmpresa;
    }

    public void setRegistroEmpresa(String registroEmpresa) {
        this.registroEmpresa = registroEmpresa;
    }

    public Double getRendaBasica() {
        return rendaBasica;
    }

    public void setRendaBasica(Double rendaBasica) {
        this.rendaBasica = rendaBasica;
    }

    public void setComissao(Comissao comissao) {
        this.comissao = comissao;
    }

    public Double calcularRendaTotal() {
        double rendaTotal = rendaBasica;

        if (comissao != null) {
            rendaTotal += comissao.getValorComissao();
        }

        return rendaTotal;
    }

    @Override
    public String toString() {
        String tipoComissao = (comissao != null) ? comissao.getClass().getSimpleName() : "Sem Comissão";
        return "Nome: " + nome +
                ", Comissão: " + tipoComissao +
                ", Salário Total: R$ " + String.format("%.2f", calcularRendaTotal());
    }

}