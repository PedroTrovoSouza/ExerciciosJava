package empresa.atividadeEmpresa;

public class FuncionarioBasico extends Funcionario {
    protected String escolaBasico;

    public FuncionarioBasico(String nome, String registroEmpresa, String escolaBasico) {
        super(nome, registroEmpresa);
        this.escolaBasico = escolaBasico;
    }

    @Override
    public Double calcularRendaTotal() {
        double renda = rendaBasica * 1.10; // 10% a mais
        if (comissao != null) {
            renda += comissao.getValorComissao();
        }
        return renda;
    }
}