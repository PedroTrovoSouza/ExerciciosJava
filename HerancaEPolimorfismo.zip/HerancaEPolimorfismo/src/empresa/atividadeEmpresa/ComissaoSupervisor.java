package empresa.atividadeEmpresa;

public class ComissaoSupervisor extends Comissao {
    @Override
    public double getValorComissao() {
        return 600.0;
    }
}
