package empresa.atividadeEmpresa;

public class Main {
    public static void main(String[] args) {
        Funcionario[] funcionarios = new Funcionario[10];

        funcionarios[0] = new FuncionarioBasico("João", "001", "Escola A");
        funcionarios[1] = new FuncionarioBasico("Maria", "002", "Escola B");
        funcionarios[2] = new FuncionarioBasico("Lucas", "003", "Escola C");
        funcionarios[3] = new FuncionarioBasico("Ana", "004", "Escola D");

        funcionarios[4] = new FuncionarioMedio("Carlos", "005", "Escola E", "Escola F");
        funcionarios[5] = new FuncionarioMedio("Paula", "006", "Escola G", "Escola H");
        funcionarios[6] = new FuncionarioMedio("Rafael", "007", "Escola I", "Escola J");
        funcionarios[7] = new FuncionarioMedio("Júlia", "008", "Escola K", "Escola L");

        funcionarios[8] = new FuncionarioGraduado("Leonardo", "009", "Escola M", "Escola N", "UFABC");
        funcionarios[9] = new FuncionarioGraduado("Bruna", "010", "Escola O", "Escola P", "USP");

        funcionarios[0].setComissao(new ComissaoGerente());     // 1 gerente
        funcionarios[1].setComissao(new ComissaoSupervisor());  // 2 supervisores
        funcionarios[2].setComissao(new ComissaoSupervisor());
        for (int i = 3; i < 10; i++) {
            funcionarios[i].setComissao(new ComissaoVendedor()); // 7 vendedores
        }

        double totalBasico = 0;
        double totalMedio = 0;
        double totalSuperior = 0;
        double totalGeral = 0;

        for (Funcionario f : funcionarios) {
            double renda = f.calcularRendaTotal();
            totalGeral += renda;

            if (f instanceof FuncionarioGraduado) {
                totalSuperior += renda;
            } else if (f instanceof FuncionarioMedio) {
                totalMedio += renda;
            } else if (f instanceof FuncionarioBasico) {
                totalBasico += renda;
            }
        }

        System.out.println("Custo total da empresa com salários: R$ " + totalGeral);
        System.out.println("Custo com Ensino Básico: R$ " + totalBasico);
        System.out.println("Custo com Ensino Médio: R$ " + totalMedio);
        System.out.println("Custo com Ensino Superior: R$ " + totalSuperior);

        System.out.println("\n--- Lista de Funcionários ---");
        for (Funcionario f : funcionarios) {
            System.out.println(f);
        }
    }
}
