package empresa.atividadeEmpresa;

public class ComissaoVendedor extends Comissao {
    @Override
    public double getValorComissao() {
        return 250.0;
    }
}