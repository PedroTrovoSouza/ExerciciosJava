package empresa;

public class Preguica extends Animal{
    @Override
    public void emitirSom() {
        System.out.println("Barulho de preguiça");
    }

    @Override
    public void moverse() {
        System.out.println("Subir em arvore");
    }
}
